import socket
import threading
import tkinter as tk
from crypto_utils import encrypt_message, decrypt_message

HOST = "127.0.0.1"
PORT = 5555

class ChatClient:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((HOST, PORT))

        self.root = tk.Tk()
        self.root.title("Encrypted Chat (E2EE)")

        self.text_area = tk.Text(self.root, height=20, width=50)
        self.text_area.pack()

        self.entry = tk.Entry(self.root, width=40)
        self.entry.pack(side=tk.LEFT)

        self.send_btn = tk.Button(self.root, text="Send", command=self.send_message)
        self.send_btn.pack(side=tk.LEFT)

        # Start receive thread
        threading.Thread(target=self.receive_messages, daemon=True).start()

        self.root.mainloop()

    def send_message(self):
        msg = self.entry.get()
        if not msg:
            return

        self.text_area.insert(tk.END, f"You: {msg}\n")
        self.entry.delete(0, tk.END)

        encrypted = encrypt_message(msg)
        self.sock.sendall(encrypted)

    def receive_messages(self):
        while True:
            try:
                data = self.sock.recv(4096)
                if not data:
                    break

                msg = decrypt_message(data)
                self.text_area.insert(tk.END, f"Peer: {msg}\n")

            except:
                break

if __name__ == "__main__":
    ChatClient()
