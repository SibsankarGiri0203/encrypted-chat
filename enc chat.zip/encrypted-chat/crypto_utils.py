from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

KEY = b"ThisIsA16ByteKey"   # Pre-shared key (16 bytes for AES-128)

def encrypt_message(message: str) -> bytes:
    iv = get_random_bytes(16)
    cipher = AES.new(KEY, AES.MODE_CBC, iv)

    data = message.encode()
    pad_len = 16 - (len(data) % 16)
    data += bytes([pad_len]) * pad_len

    encrypted = cipher.encrypt(data)
    return base64.b64encode(iv + encrypted)

def decrypt_message(enc: bytes) -> str:
    raw = base64.b64decode(enc)
    iv = raw[:16]
    ciphertext = raw[16:]

    cipher = AES.new(KEY, AES.MODE_CBC, iv)
    data = cipher.decrypt(ciphertext)

    pad_len = data[-1]
    return data[:-pad_len].decode()
