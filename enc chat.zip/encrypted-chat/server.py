import socket
import threading

HOST = "127.0.0.1"
PORT = 5555

clients = []

def handle_client(conn, addr):
    print(f"[+] Client connected: {addr}")
    while True:
        try:
            data = conn.recv(4096)
            if not data:
                break

            # Server sees encrypted gibberish
            print(f"[ENCRYPTED FROM {addr}]: {data}")

            # Broadcast to all OTHER clients
            for c in clients:
                if c != conn:
                    c.sendall(data)

        except:
            break

    print(f"[-] Client disconnected: {addr}")
    clients.remove(conn)
    conn.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()

    print(f"[SERVER STARTED] {HOST}:{PORT}")

    while True:
        conn, addr = server.accept()
        clients.append(conn)
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_server()
