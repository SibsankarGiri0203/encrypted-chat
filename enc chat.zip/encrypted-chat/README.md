# End-to-End Encrypted Chat App

## Features
- End-to-end encryption (server cannot read messages)
- X25519 key exchange
- AES-GCM authenticated encryption
- GUI client (Tkinter)
- Multi-client relay server
- Server logs ciphertext only

## Setup

### Install deps
```bash
pip install -r requirements.txt
